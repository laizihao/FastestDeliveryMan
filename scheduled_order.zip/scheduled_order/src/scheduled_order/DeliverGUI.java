package scheduled_order;

import java.util.*;
import javax.swing.*;
import javax.swing.table.*;

public class DeliverGUI extends javax.swing.JFrame {

    public DeliverGUI() {
        initComponents();
        //use addRowToJTable
        addOrderToJTable();
        addDeliverymanToJTable();
    }

    //create class Scheduledorder and use it to populate the arrraylist
    public class ScheduledOrder {

        public String date;
        public String id;
        public String time;
        public String area;
        public String address;
        public String assigned;

        public ScheduledOrder(String date, String id, String time, String area, String address, String assigned) {
            this.date = date;
            this.id = id;
            this.time = time;
            this.area = area;
            this.address = address;
            this.assigned = assigned;
        }
    }

    public class Deliveryman {

        public String name;
        public String deliveryArea;
        public int orders;
        public String delivers;

        public Deliveryman(String name, String deliveryArea, int orders, String delivers) {
            this.name = name;
            this.deliveryArea = deliveryArea;
            this.orders = orders;
            this.delivers = delivers;
        }
    }

    //create order list
    public ArrayList orderList() {
        ArrayList<ScheduledOrder> orders = new ArrayList<>();
        ScheduledOrder o1 = new ScheduledOrder("Nov 30", "01", "13:30", "Area1", "abcd", "No");
        ScheduledOrder o2 = new ScheduledOrder("Nov 30", "02", "15:00", "Area2", "bcde", "No");
        ScheduledOrder o3 = new ScheduledOrder("Nov 30", "03", "10:00", "Area2", "bcde", "No");
        ScheduledOrder o4 = new ScheduledOrder("Nov 30", "04", "11:30", "Area1", "abcd", "No");
        orders.add(o1);
        orders.add(o2);
        orders.add(o3);
        orders.add(o4);
        return orders;
    }

    public ArrayList DeliverymanList() {
        ArrayList<Deliveryman> deliveryman = new ArrayList<>();
        Deliveryman d1 = new Deliveryman("Dave", "Area1", 0, "");
        Deliveryman d2 = new Deliveryman("Jack", "Area2", 0, "");
        Deliveryman d3 = new Deliveryman("Will", "Area1", 0, "");
        Deliveryman d4 = new Deliveryman("Rick", "Area2", 3, "");
        deliveryman.add(d1);
        deliveryman.add(d2);
        deliveryman.add(d3);
        deliveryman.add(d4);
        return deliveryman;
    }

    //add order from arraylist to jtable
    public void addOrderToJTable() {
        DefaultTableModel OrderModel = (DefaultTableModel) jTableOrders.getModel();
        ArrayList<ScheduledOrder> orders = orderList();
        Object rowData[] = new Object[6];
        for (int i = 0; i < orders.size(); i++) {
            rowData[0] = orders.get(i).date;
            rowData[1] = orders.get(i).id;
            rowData[2] = orders.get(i).time;
            rowData[3] = orders.get(i).area;
            rowData[4] = orders.get(i).address;
            rowData[5] = orders.get(i).assigned;
            OrderModel.addRow(rowData);
        }
        //table auto sorting
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(jTableOrders.getModel());
        jTableOrders.setRowSorter(sorter);
        ArrayList<RowSorter.SortKey> sortKeys = new ArrayList<>();
        int columnIndexToSort = 3;
        sortKeys.add(new RowSorter.SortKey(columnIndexToSort, SortOrder.ASCENDING));
        sorter.setSortKeys(sortKeys);
        sorter.sort();

    }

    public void addDeliverymanToJTable() {
        DefaultTableModel DeliverymanModel = (DefaultTableModel) jTableDeliveryman.getModel();
        ArrayList<Deliveryman> deliveryman = DeliverymanList();
        Object rowData[] = new Object[4];
        for (int i = 0; i < deliveryman.size(); i++) {
            rowData[0] = deliveryman.get(i).name;
            rowData[1] = deliveryman.get(i).deliveryArea;
            rowData[2] = deliveryman.get(i).orders;
            rowData[3] = deliveryman.get(i).delivers;
            DeliverymanModel.addRow(rowData);
        }
        //table auto sorting
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(jTableDeliveryman.getModel());
        jTableDeliveryman.setRowSorter(sorter);
        ArrayList<RowSorter.SortKey> sortKeys = new ArrayList<>();
        int columnIndexToSort = 1;
        sortKeys.add(new RowSorter.SortKey(columnIndexToSort, SortOrder.ASCENDING));
        sorter.setSortKeys(sortKeys);
        sorter.sort();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTableDeliveryman = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableOrders = new javax.swing.JTable();
        btnAssign = new javax.swing.JButton();
        btnClose = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jTableDeliveryman.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Delivery area", "Orders", "Delivers"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableDeliveryman.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTableDeliveryman);
        if (jTableDeliveryman.getColumnModel().getColumnCount() > 0) {
            jTableDeliveryman.getColumnModel().getColumn(0).setResizable(false);
            jTableDeliveryman.getColumnModel().getColumn(1).setResizable(false);
            jTableDeliveryman.getColumnModel().getColumn(2).setResizable(false);
            jTableDeliveryman.getColumnModel().getColumn(3).setResizable(false);
        }

        jTableOrders.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Date", "ID", "Time", "Area", "Address", "Assigned"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableOrders.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(jTableOrders);
        if (jTableOrders.getColumnModel().getColumnCount() > 0) {
            jTableOrders.getColumnModel().getColumn(0).setResizable(false);
            jTableOrders.getColumnModel().getColumn(1).setResizable(false);
            jTableOrders.getColumnModel().getColumn(2).setResizable(false);
            jTableOrders.getColumnModel().getColumn(3).setResizable(false);
            jTableOrders.getColumnModel().getColumn(4).setResizable(false);
            jTableOrders.getColumnModel().getColumn(5).setResizable(false);
        }

        btnAssign.setText("Assign >>");
        btnAssign.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAssignActionPerformed(evt);
            }
        });

        btnClose.setText("Close");
        btnClose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCloseActionPerformed(evt);
            }
        });

        jLabel1.setText("Scheduled order list:");

        jLabel2.setText("Deliverymen list:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Assign scheduled orders:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel3))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btnAssign, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(358, 358, 358))))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnAssign)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnClose)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAssignActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAssignActionPerformed
        int OrderRow = jTableOrders.getSelectedRow();
        int DeliverymanRow = jTableDeliveryman.getSelectedRow();

        DefaultTableModel OrderModel = (DefaultTableModel) jTableOrders.getModel();
        DefaultTableModel DeliverymanModel = (DefaultTableModel) jTableDeliveryman.getModel();

        if (OrderRow >= 0 && DeliverymanRow >= 0) {
            String orderAssigned = OrderModel.getValueAt(jTableOrders.convertRowIndexToModel(OrderRow), 5).toString();
            String assignedOrderID = OrderModel.getValueAt(jTableOrders.convertRowIndexToModel(OrderRow), 1).toString();
            String assignedName = DeliverymanModel.getValueAt(jTableDeliveryman.convertRowIndexToModel(DeliverymanRow), 0).toString();
            int orderCount = Integer.parseInt(DeliverymanModel.getValueAt(jTableDeliveryman.convertRowIndexToModel(DeliverymanRow), 2).toString());
            String delivers = DeliverymanModel.getValueAt(jTableDeliveryman.convertRowIndexToModel(DeliverymanRow), 3).toString();
            String orderArea = OrderModel.getValueAt(jTableOrders.convertRowIndexToModel(OrderRow), 3).toString();
            String deliverArea = DeliverymanModel.getValueAt(jTableDeliveryman.convertRowIndexToModel(DeliverymanRow), 1).toString();

            if ("No".equals(orderAssigned)) {
                if (orderCount < 3) {
                    if (deliverArea.equals(orderArea)) {
                        //upates for order table
                        OrderModel.setValueAt(assignedName, jTableOrders.convertRowIndexToModel(OrderRow), 5);
                        //upates for deliveryman table
                        delivers += "#" + assignedOrderID;
                        DeliverymanModel.setValueAt(orderCount + 1, jTableDeliveryman.convertRowIndexToModel(DeliverymanRow), 2);
                        DeliverymanModel.setValueAt(delivers, jTableDeliveryman.convertRowIndexToModel(DeliverymanRow), 3);
                    } else {
                        JOptionPane.showMessageDialog(null, "The selected order is not within the deliveryman's delivery area");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "The selected deliveryman has reached the maximum deliveries");
                }
            } else {
                JOptionPane.showMessageDialog(null, "The selected order has already been assigned");
            }
        } else {
            JOptionPane.showMessageDialog(null, "No order or deliveryman selected");
        }

    }//GEN-LAST:event_btnAssignActionPerformed

    private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnCloseActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DeliverGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DeliverGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DeliverGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DeliverGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DeliverGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAssign;
    private javax.swing.JButton btnClose;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTableDeliveryman;
    private javax.swing.JTable jTableOrders;
    // End of variables declaration//GEN-END:variables
}
